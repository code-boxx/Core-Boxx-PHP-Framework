<?php

namespace Flow;

class FileLockException extends \Exception
{
}
