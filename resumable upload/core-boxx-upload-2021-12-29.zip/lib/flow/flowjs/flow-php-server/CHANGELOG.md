# 1.0.0
## Breaking Changes
 * Flow\Exception was replaced by Flow\FileOpenException and Flow\FileLockException
 * php requirement was changed to >=5.4
 * if chunk was not found, 204 status is returned instead of 404