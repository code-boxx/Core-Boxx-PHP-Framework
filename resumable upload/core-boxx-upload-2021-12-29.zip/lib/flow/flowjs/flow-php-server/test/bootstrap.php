<?php

require_once(__DIR__ . '/../vendor/autoload.php');
require_once(__DIR__ . '/../src/Flow/Autoloader.php');
require_once(__DIR__ . '/Unit/FlowUnitCase.php');

Flow\Autoloader::register();
