# Security Policy

## Supported Versions

| Version | Supported          |
|---------| ------------------ |
| 1.0.x   | :white_check_mark: |
| < 1.0.0 | :x:                |

## Reporting a Vulnerability

If you think you have found a security issue, DO NOT open an issue. You MUST email your issue: security AT
spomky-labs.com.
